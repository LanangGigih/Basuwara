# basuwara
Basuwara is an educational mobile application designed to promote the learning and preservation of traditional Indonesian scripts. This app then represents an opportunity to bridge the gap between the modern digital age and Indonesia's linguistic heritage, by providing an easy and exciting learning process for everyone.
