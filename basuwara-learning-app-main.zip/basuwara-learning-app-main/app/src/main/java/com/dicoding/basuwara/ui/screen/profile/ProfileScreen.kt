package com.dicoding.basuwara.ui.screen.profile

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.LineHeightStyle

@Composable
fun ProfileScreen(

) {
    Box{
        Text(text = "Not yet implemented", modifier = Modifier.fillMaxSize().align(Alignment.Center))
    }
}